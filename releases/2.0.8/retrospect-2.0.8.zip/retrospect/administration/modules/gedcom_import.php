<?php 
	/**
	* @copyright 	Keith Morrison, Infused Solutions	2001-2006
	* @author			Keith Morrison <keithm@infused-solutions.com>
	* @package 		Administration
	* @license http://opensource.org/licenses/gpl-license.php
	*
	* This program is free software; you can redistribute it and/or
	* modify it under the terms of the GNU General Public License
	* as published by the Free Software Foundation; either version 2
	* of the License, or (at your option) any later version.
	
	* This program is distributed in the hope that it will be useful,
	* but WITHOUT ANY WARRANTY; without even the implied warranty of
	* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	* GNU General Public License contained in the file GNU.txt for
	* more details.
	*/
	
	/**
	* $Id: gedcom_import.php 595 2006-11-15 01:17:17Z kmorrison $
	*/
	
	$smarty->assign('page_title', 'Retrospect-GDS Administration');
	
	$file = $_GET['f'];
	$smarty->assign('GEDCOM_FILE', $file);

?>